namespace admob
{
    public class AdmobGender
    {
      public static readonly int   MALE = 1;
      public static readonly int  FEMAIL = 2;
    }
}
